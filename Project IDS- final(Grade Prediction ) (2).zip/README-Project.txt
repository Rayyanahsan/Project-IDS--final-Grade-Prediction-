# Student Exam Score Prediction with Linear Regression

This read me file contains Student Grade Analysis And Prediction model developed using the 
python and diffrent libraries such as numpy, matplotlib, seaborn, pandas to predict students' 
grades based on various attributes. 
The model is trained on one dataset: Training dataset final.xlsx

## Dataset Features

The dataset share the following attributes:

- Sex(Male or Female)
- Scholarship(numeric: 10% to 100%)
- parents job(categorical: health, other, teacher, private etc)
- parents education(categorical: primary, secondary, higher)
- reading(categorical: Yes or No)
- notes(categorical: Yes or No)
- Age(numeric: 18 to 23)
- Weekly Study Hours(categorical: Yes or No)
- ... (and more features)

## Course Grades (Targets)

The student GRADES are the target variables for prediction.

- **Grade**: (categorical: AA,BA,BB,CB,CC,DC,DD)


## Dataset Source
The datasets used in this project are available on kaggle:
The links are here:
https://www.kaggle.com/datasets/jacksondivakarr/student-classification-dataset
https://www.kaggle.com/datasets/rkiattisak/student-performance-in-mathematics


## Usage

The Jupyter Notebook files provided in this read me file demonstrate the steps involved 
in data preprocessing, model training using python, and evaluation of the 
predictive performance. 
The "Training dataset file.xlsx" dataset is included for reference.

## Requirements

To run the code, ensure you have:
- Python installed
- JuPyter Notebooks
- Necessary libraries: `sklearn`, `NumPy`, `pandas`, `matplotlib`, and `seaborn`

## About This Project

This project serves as personal training and learning in machine learning and data analysis, 
focusing on predicting students' grades.

